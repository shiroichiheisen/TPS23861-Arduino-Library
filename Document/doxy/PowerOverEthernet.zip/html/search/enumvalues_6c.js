var searchData=
[
  ['legacy_5fdetect_5fdisabled',['LEGACY_DETECT_DISABLED',['../_t_p_s23861_8h.html#a00bd08591e39dadf3a5f95ebd7d5732da04962d335ff80c0b911a7053349970d8',1,'TPS23861.h']]],
  ['legacy_5fdetect_5fonly',['LEGACY_DETECT_ONLY',['../_t_p_s23861_8h.html#a00bd08591e39dadf3a5f95ebd7d5732da06b10e2bd12a97a9da410402ba6abf2b',1,'TPS23861.h']]],
  ['legacy_5fdetect_5fstandard_5fthen_5flegacy',['LEGACY_DETECT_STANDARD_THEN_LEGACY',['../_t_p_s23861_8h.html#a00bd08591e39dadf3a5f95ebd7d5732da6a71860972afd121cf87f44fbda94f61',1,'TPS23861.h']]]
];
