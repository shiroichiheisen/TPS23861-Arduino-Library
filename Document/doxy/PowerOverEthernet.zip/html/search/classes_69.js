var searchData=
[
  ['input_5fvoltage_5fchar_5ft',['Input_Voltage_Char_t',['../struct_t_p_s238x___input___voltage___register__u_1_1_input___voltage___char__t.html',1,'TPS238x_Input_Voltage_Register_u']]],
  ['input_5fvoltage_5fshort_5ft',['Input_Voltage_Short_t',['../struct_t_p_s238x___input___voltage___register__u_1_1_input___voltage___short__t.html',1,'TPS238x_Input_Voltage_Register_u']]]
];
