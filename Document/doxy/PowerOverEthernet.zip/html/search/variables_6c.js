var searchData=
[
  ['legmod1_5flegacy_5fdetect_5fport_5f1',['LEGMOD1_Legacy_Detect_Port_1',['../struct_t_p_s238x___legacy___detect___register__t.html#ad94e0297bc8ebfad0329c43a2a9cb78a',1,'TPS238x_Legacy_Detect_Register_t']]],
  ['legmod2_5flegacy_5fdetect_5fport_5f2',['LEGMOD2_Legacy_Detect_Port_2',['../struct_t_p_s238x___legacy___detect___register__t.html#a909aa93edfd901520efdec0cf68d229c',1,'TPS238x_Legacy_Detect_Register_t']]],
  ['legmod3_5flegacy_5fdetect_5fport_5f3',['LEGMOD3_Legacy_Detect_Port_3',['../struct_t_p_s238x___legacy___detect___register__t.html#a6b80e1e553d2a514fa74657eb4336b7c',1,'TPS238x_Legacy_Detect_Register_t']]],
  ['legmod4_5flegacy_5fdetect_5fport_5f4',['LEGMOD4_Legacy_Detect_Port_4',['../struct_t_p_s238x___legacy___detect___register__t.html#a8413d8a277d91edc53da8b44c7ea6691',1,'TPS238x_Legacy_Detect_Register_t']]]
];
