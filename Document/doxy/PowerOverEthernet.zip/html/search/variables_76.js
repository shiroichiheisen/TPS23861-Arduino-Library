var searchData=
[
  ['vduv_5fvdd_5fuvlo_5fevent',['VDUV_Vdd_UVLO_Event',['../struct_t_p_s238_x___supply___event___register__t.html#abab65a098bb6bdcb452e96dbf4aca4e6',1,'TPS238X_Supply_Event_Register_t']]],
  ['voltage_5fdifference_5fstatus',['Voltage_Difference_Status',['../struct_t_p_s238x___port___voltage___difference___register__u_1_1_port___voltage___difference___short__t.html#a1d4d1c9d3114fb7c7ca011c257a44275',1,'TPS238x_Port_Voltage_Difference_Register_u::Port_Voltage_Difference_Short_t::Voltage_Difference_Status()'],['../struct_t_p_s238x___port___voltage___difference___register__u_1_1_port___voltage___difference___char__t.html#af6529862fcb9b2f73e93e182a995bd0e',1,'TPS238x_Port_Voltage_Difference_Register_u::Port_Voltage_Difference_Char_t::Voltage_Difference_Status()']]],
  ['vpuv_5fvpower_5fundervoltage_5fevent',['VPUV_VPower_Undervoltage_Event',['../struct_t_p_s238_x___supply___event___register__t.html#ac6fcee7fc4bb8175466aebc576b07772',1,'TPS238X_Supply_Event_Register_t']]]
];
