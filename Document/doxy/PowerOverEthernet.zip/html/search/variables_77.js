var searchData=
[
  ['wds_5fwatchdog_5fstatus',['WDS_Watchdog_Status',['../struct_t_p_s238x___i2_c___watchdog___register__t.html#aeaba671bd7a4aa4b365b8eca951032b7',1,'TPS238x_I2C_Watchdog_Register_t']]]
];
