var searchData=
[
  ['_5f1x_5filim_5ffoldback_5fcurve',['_1X_ILIM_FOLDBACK_CURVE',['../_t_p_s23861_8h.html#a24fbde755fac6f922bd6cb9c19f86eb1a021fd3acf431e386c7434ec2efc232bb',1,'TPS23861.h']]],
  ['_5f2x_5filim_5ffoldback_5fcurve',['_2X_ILIM_FOLDBACK_CURVE',['../_t_p_s23861_8h.html#a24fbde755fac6f922bd6cb9c19f86eb1aef105560462bfba4038227762832fc1d',1,'TPS23861.h']]]
];
