var searchData=
[
  ['sumsk_5fsupply_5fevent_5ffault_5funmask',['SUMSK_Supply_Event_Fault_Unmask',['../struct_t_p_s238_x___interrupt___mask___register__t.html#a85c1d4453b3757e2311c4e4ece90e095',1,'TPS238X_Interrupt_Mask_Register_t']]],
  ['supf_5fsupply_5fevent_5ffault',['SUPF_Supply_Event_Fault',['../struct_t_p_s238_x___interrupt___register__t.html#aa574718bff2df2bd05f6a8922eb10f38',1,'TPS238X_Interrupt_Register_t']]]
];
