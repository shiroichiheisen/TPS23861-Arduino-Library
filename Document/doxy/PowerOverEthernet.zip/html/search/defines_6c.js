var searchData=
[
  ['legacy_5fmode_5fmask',['LEGACY_MODE_MASK',['../_t_p_s23861_8h.html#ade20f81528e673a7da22ccbf1fcafea6',1,'TPS23861.h']]],
  ['legmod1',['LEGMOD1',['../_t_p_s23861_8h.html#af48b6156cdb5110e692213fa64df6b35',1,'TPS23861.h']]],
  ['legmod1_5fshift',['LEGMOD1_SHIFT',['../_t_p_s23861_8h.html#a88fff9686618b862e3d73c3275cf02ec',1,'TPS23861.h']]],
  ['legmod2',['LEGMOD2',['../_t_p_s23861_8h.html#accc5b89b3b22061e1404b71eee0c6513',1,'TPS23861.h']]],
  ['legmod2_5fshift',['LEGMOD2_SHIFT',['../_t_p_s23861_8h.html#adda9e2762b7de2f7dd85aec4c81b092f',1,'TPS23861.h']]],
  ['legmod3',['LEGMOD3',['../_t_p_s23861_8h.html#ab624c69ce03d6ad1531c6846cc3463ad',1,'TPS23861.h']]],
  ['legmod3_5fshift',['LEGMOD3_SHIFT',['../_t_p_s23861_8h.html#ae979252bda7a5c7b836583b82c1a38b9',1,'TPS23861.h']]],
  ['legmod4',['LEGMOD4',['../_t_p_s23861_8h.html#ace5bfee3cd2fe3264fb46db6f41e4d00',1,'TPS23861.h']]],
  ['legmod4_5fshift',['LEGMOD4_SHIFT',['../_t_p_s23861_8h.html#a0b8e2d8f04f0945f28d5a99f8e4d65f9',1,'TPS23861.h']]]
];
