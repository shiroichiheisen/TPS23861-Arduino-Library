var searchData=
[
  ['vds_5fstatus_5ffirst_5fmeasurement_5fexcess',['VDS_STATUS_FIRST_MEASUREMENT_EXCESS',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55aa4f84618a8aa657e5db3a602c7770508',1,'TPS23861.h']]],
  ['vds_5fstatus_5finsufficient_5fsignal',['VDS_STATUS_INSUFFICIENT_SIGNAL',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55acab06917d2b3461f432f96995d5351a2',1,'TPS23861.h']]],
  ['vds_5fstatus_5fpower_5fon_5freset',['VDS_STATUS_POWER_ON_RESET',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55ab5a7f055810c4429925ab5aafb8e5304',1,'TPS23861.h']]],
  ['vds_5fstatus_5fsecond_5fmeasurement_5fexcess',['VDS_STATUS_SECOND_MEASUREMENT_EXCESS',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55a82e10ae08107447a9e21bc3c8ee1e2d1',1,'TPS23861.h']]],
  ['vds_5fstatus_5ftimeout',['VDS_STATUS_TIMEOUT',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55afe67465beff732b824b160510cb8489d',1,'TPS23861.h']]],
  ['vds_5fstatus_5fvalid_5fmeasurement',['VDS_STATUS_VALID_MEASUREMENT',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55a6d8964396f53727888a5902471795b06',1,'TPS23861.h']]]
];
