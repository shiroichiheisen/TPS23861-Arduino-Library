var searchData=
[
  ['mains_5fdetection_5fvoltage_5fmeasurement_5fduration',['MAINS_Detection_Voltage_Measurement_Duration',['../struct_t_p_s238x___general___mask__1___register__t.html#a4ca38d0397f133021ee0abaeb61d7e66',1,'TPS238x_General_Mask_1_Register_t']]],
  ['mfr_5fid_5fmanufacture_5fid_5fnumber',['MFR_ID_Manufacture_ID_Number',['../struct_t_p_s238x___i_d___register__t.html#a2692e9107a90c7b9ffc0d4be7b68feb6',1,'TPS238x_ID_Register_t']]]
];
