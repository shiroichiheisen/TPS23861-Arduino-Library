var searchData=
[
  ['vds_5fmask_5fshort',['VDS_MASK_SHORT',['../_t_p_s23861_8h.html#a426f635e50640ce1f7327dc702ff5d89',1,'TPS23861.h']]],
  ['vds_5fshift_5fshort',['VDS_SHIFT_SHORT',['../_t_p_s23861_8h.html#a8ad9e6a076ad2b1a27de08a8c2e18a87',1,'TPS23861.h']]],
  ['vds_5fstatus_5ffirst_5fmeasurement_5fexcess',['VDS_STATUS_FIRST_MEASUREMENT_EXCESS',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55aa4f84618a8aa657e5db3a602c7770508',1,'TPS23861.h']]],
  ['vds_5fstatus_5finsufficient_5fsignal',['VDS_STATUS_INSUFFICIENT_SIGNAL',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55acab06917d2b3461f432f96995d5351a2',1,'TPS23861.h']]],
  ['vds_5fstatus_5fpower_5fon_5freset',['VDS_STATUS_POWER_ON_RESET',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55ab5a7f055810c4429925ab5aafb8e5304',1,'TPS23861.h']]],
  ['vds_5fstatus_5fsecond_5fmeasurement_5fexcess',['VDS_STATUS_SECOND_MEASUREMENT_EXCESS',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55a82e10ae08107447a9e21bc3c8ee1e2d1',1,'TPS23861.h']]],
  ['vds_5fstatus_5ftimeout',['VDS_STATUS_TIMEOUT',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55afe67465beff732b824b160510cb8489d',1,'TPS23861.h']]],
  ['vds_5fstatus_5fvalid_5fmeasurement',['VDS_STATUS_VALID_MEASUREMENT',['../_t_p_s23861_8h.html#a65599a8ba36a478f64cd5b49fc3f3f55a6d8964396f53727888a5902471795b06',1,'TPS23861.h']]],
  ['vduv',['VDUV',['../_t_p_s23861_8h.html#af975ac64f49b62ea3cd0c6edd5671ae6',1,'TPS23861.h']]],
  ['vduv_5fvdd_5fuvlo_5fevent',['VDUV_Vdd_UVLO_Event',['../struct_t_p_s238_x___supply___event___register__t.html#abab65a098bb6bdcb452e96dbf4aca4e6',1,'TPS238X_Supply_Event_Register_t']]],
  ['voltage_5fdifference_5fstatus',['Voltage_Difference_Status',['../struct_t_p_s238x___port___voltage___difference___register__u_1_1_port___voltage___difference___short__t.html#a1d4d1c9d3114fb7c7ca011c257a44275',1,'TPS238x_Port_Voltage_Difference_Register_u::Port_Voltage_Difference_Short_t::Voltage_Difference_Status()'],['../struct_t_p_s238x___port___voltage___difference___register__u_1_1_port___voltage___difference___char__t.html#af6529862fcb9b2f73e93e182a995bd0e',1,'TPS238x_Port_Voltage_Difference_Register_u::Port_Voltage_Difference_Char_t::Voltage_Difference_Status()']]],
  ['vpuv',['VPUV',['../_t_p_s23861_8h.html#a118dd126ff9ab07bbb0cecd4f438f360',1,'TPS23861.h']]],
  ['vpuv_5fvpower_5fundervoltage_5fevent',['VPUV_VPower_Undervoltage_Event',['../struct_t_p_s238_x___supply___event___register__t.html#ac6fcee7fc4bb8175466aebc576b07772',1,'TPS238X_Supply_Event_Register_t']]]
];
